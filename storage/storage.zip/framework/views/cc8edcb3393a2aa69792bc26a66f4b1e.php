<?php $__env->startSection('title', 'Profil PPID'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold text-gray-900 mb-6">Kelola Profil PPID</h1>

<?php if(session('success')): ?>
<div class="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700 text-sm"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.profil.update')); ?>" enctype="multipart/form-data" class="space-y-6">
    <?php echo csrf_field(); ?>

    <?php
    $sections = [
        'profil_tentang_teks' => ['label' => 'Tentang PPID', 'rows' => 6],
        'profil_visi_teks' => ['label' => 'Visi PPID', 'rows' => 3],
        'profil_misi_teks' => ['label' => 'Misi PPID', 'rows' => 8],
        'profil_tugas_teks' => ['label' => 'Tugas dan Fungsi', 'rows' => 12],
        'profil_dasar_hukum_teks' => ['label' => 'Dasar Hukum', 'rows' => 6],
        'profil_maklumat_teks' => ['label' => 'Maklumat Pelayanan', 'rows' => 6],
        'profil_standar_teks' => ['label' => 'Standar Pelayanan', 'rows' => 8],
    ];
    ?>

    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-lg shadow p-6">
        <?php if (isset($component)) { $__componentOriginal030291ebfbe01b7b21fc10c5b0c01e4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal030291ebfbe01b7b21fc10c5b0c01e4c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quill-editor','data' => ['name' => ''.e($key).'','value' => old($key, $settings[$key]->value ?? ''),'label' => $config['label'],'height' => '150px']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quill-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($key).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old($key, $settings[$key]->value ?? '')),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($config['label']),'height' => '150px']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal030291ebfbe01b7b21fc10c5b0c01e4c)): ?>
<?php $attributes = $__attributesOriginal030291ebfbe01b7b21fc10c5b0c01e4c; ?>
<?php unset($__attributesOriginal030291ebfbe01b7b21fc10c5b0c01e4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal030291ebfbe01b7b21fc10c5b0c01e4c)): ?>
<?php $component = $__componentOriginal030291ebfbe01b7b21fc10c5b0c01e4c; ?>
<?php unset($__componentOriginal030291ebfbe01b7b21fc10c5b0c01e4c); ?>
<?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="bg-white rounded-lg shadow p-6">
        <label class="input-label mb-3">Gambar Struktur Organisasi</label>
        <?php if (isset($component)) { $__componentOriginaldbebdfa49a0907927fe266159631a348 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbebdfa49a0907927fe266159631a348 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.image-upload','data' => ['name' => 'profil_struktur_gambar','current' => $strukturUrl ? true : false,'currentUrl' => $strukturUrl]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('image-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'profil_struktur_gambar','current' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($strukturUrl ? true : false),'currentUrl' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($strukturUrl)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbebdfa49a0907927fe266159631a348)): ?>
<?php $attributes = $__attributesOriginaldbebdfa49a0907927fe266159631a348; ?>
<?php unset($__attributesOriginaldbebdfa49a0907927fe266159631a348); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbebdfa49a0907927fe266159631a348)): ?>
<?php $component = $__componentOriginaldbebdfa49a0907927fe266159631a348; ?>
<?php unset($__componentOriginaldbebdfa49a0907927fe266159631a348); ?>
<?php endif; ?>
        <p class="text-xs text-gray-500 mt-2">Upload gambar struktur organisasi PPID. Format: JPG, PNG, WEBP, SVG. Maks: 5MB</p>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
        <label class="input-label mb-3">SK PPID (Surat Keputusan Penetapan PPID)</label>
        <?php if($skUploaded): ?>
            <div class="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg mb-3">
                <svg class="w-5 h-5 text-green-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <span class="text-sm text-green-700 flex-1">File terupload: <strong><?php echo e($skFileName); ?></strong></span>
                <a href="<?php echo e(route('admin.profil.download-sk')); ?>" class="text-sm text-primary hover:underline font-medium">Download</a>
            </div>
        <?php endif; ?>
        <input type="file" name="profil_sk_file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" class="input-field w-full">
        <p class="text-xs text-gray-500 mt-1">Format: PDF, DOC, DOCX, JPG, PNG. Maks: 10MB. Kosongkan jika tidak ingin mengubah.</p>
    </div>

    <div class="flex gap-3">
        <button type="submit" class="btn-primary">Simpan Semua Perubahan</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MyPC One Pro L\Documents\website\ppid3.0\ppid-bpmpntb\resources\views/admin/profil/index.blade.php ENDPATH**/ ?>