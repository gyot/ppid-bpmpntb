<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name' => 'foto', 'current' => null, 'currentUrl' => null, 'accept' => '.jpg,.jpeg,.png,.webp', 'maxSize' => '2MB']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name' => 'foto', 'current' => null, 'currentUrl' => null, 'accept' => '.jpg,.jpeg,.png,.webp', 'maxSize' => '2MB']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<style>
    .drop-zone { border: 2px dashed #cbd5e1; border-radius: 0.75rem; transition: all 0.2s; cursor: pointer; position: relative; overflow: hidden; }
    .drop-zone:hover, .drop-zone.drag-over { border-color: #2563eb; background: #eff6ff; }
    .drop-zone.has-image { border-style: solid; border-color: #e2e8f0; }
    .drop-zone input[type="file"] { position: absolute; inset: 0; opacity: 0; cursor: pointer; z-index: 2; }
    .drop-zone .preview-img { width: 100%; height: 180px; object-fit: cover; border-radius: 0.5rem; }
    .drop-zone .remove-btn { position: absolute; top: 8px; right: 8px; z-index: 3; width: 28px; height: 28px; border-radius: 9999px; background: #ef4444; color: white; display: flex; align-items: center; justify-content: center; cursor: pointer; border: none; font-size: 14px; }
    .drop-zone .remove-btn:hover { background: #dc2626; }
</style>

<div id="drop-<?php echo e($name); ?>" class="drop-zone <?php echo e($current ? 'has-image' : ''); ?>" style="padding: <?php echo e($current ? '12px' : '24px'); ?>; text-align: center;">
    <input type="file" name="<?php echo e($name); ?>" id="input-<?php echo e($name); ?>" accept="<?php echo e($accept); ?>" onchange="handleFileSelect<?php echo e($name); ?>(this)">

    <div id="placeholder-<?php echo e($name); ?>" style="display: <?php echo e($current ? 'none' : 'block'); ?>;">
        <svg class="w-10 h-10 text-gray-300 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        <p class="text-sm text-gray-500 mb-1">Klik, paste (Ctrl+V), atau seret gambar ke sini</p>
        <p class="text-xs text-gray-400">Format: JPG, PNG, WEBP. Maks: <?php echo e($maxSize); ?></p>
    </div>

    <div id="preview-<?php echo e($name); ?>" style="display: <?php echo e($current ? 'block' : 'none'); ?>;">
        <img id="img-<?php echo e($name); ?>" src="<?php echo e($currentUrl); ?>" class="preview-img" style="display: <?php echo e($currentUrl ? 'block' : 'none'); ?>;">
        <button type="button" class="remove-btn" onclick="removeImage<?php echo e($name); ?>()" title="Hapus gambar">&times;</button>
    </div>
</div>

<script>
(function() {
    var dropZone = document.getElementById('drop-<?php echo e($name); ?>');
    var input = document.getElementById('input-<?php echo e($name); ?>');
    var placeholder = document.getElementById('placeholder-<?php echo e($name); ?>');
    var preview = document.getElementById('preview-<?php echo e($name); ?>');
    var img = document.getElementById('img-<?php echo e($name); ?>');

    // Drag events
    dropZone.addEventListener('dragover', function(e) { e.preventDefault(); dropZone.classList.add('drag-over'); });
    dropZone.addEventListener('dragleave', function(e) { e.preventDefault(); dropZone.classList.remove('drag-over'); });
    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
        var files = e.dataTransfer.files;
        if (files.length > 0 && files[0].type.startsWith('image/')) {
            input.files = files;
            showPreview(files[0]);
        }
    });

    // Paste event
    document.addEventListener('paste', function(e) {
        if (document.activeElement === dropZone || dropZone.contains(document.activeElement)) {
            var items = e.clipboardData.items;
            for (var i = 0; i < items.length; i++) {
                if (items[i].type.startsWith('image/')) {
                    e.preventDefault();
                    var file = items[i].getAsFile();
                    var dt = new DataTransfer();
                    dt.items.add(file);
                    input.files = dt.files;
                    showPreview(file);
                    return;
                }
            }
        }
    });

    // Click to focus for paste
    dropZone.addEventListener('click', function(e) {
        if (e.target.tagName !== 'BUTTON' && e.target.tagName !== 'INPUT') {
            // Don't trigger file input on click if we want paste support
            // Only trigger on actual file input click
        }
    });

    window['handleFileSelect<?php echo e($name); ?>'] = function(el) {
        if (el.files[0]) showPreview(el.files[0]);
    };

    window['removeImage<?php echo e($name); ?>'] = function() {
        input.value = '';
        img.src = '';
        img.style.display = 'none';
        preview.style.display = 'none';
        placeholder.style.display = 'block';
        dropZone.classList.remove('has-image');
        dropZone.style.padding = '24px';
    };

    function showPreview(file) {
        var reader = new FileReader();
        reader.onload = function(e) {
            img.src = e.target.result;
            img.style.display = 'block';
            preview.style.display = 'block';
            placeholder.style.display = 'none';
            dropZone.classList.add('has-image');
            dropZone.style.padding = '12px';
        };
        reader.readAsDataURL(file);
    }
})();
</script>
<?php /**PATH C:\Users\MyPC One Pro L\Documents\website\ppid3.0\ppid-bpmpntb\resources\views/components/image-upload.blade.php ENDPATH**/ ?>